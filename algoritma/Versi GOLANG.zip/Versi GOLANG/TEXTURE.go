package main

import (
	"os"
	"fmt"
	"log"
	"image"
	_"image/png"
	_"image/jpeg"
	_"image/gif"
	"github.com/lucasb-eyer/go-colorful"
	"gonum.org/v1/gonum/mat"
	"gonum.org/v1/gonum/floats"
	"math"
	"time"
)

func toBlack(img image.Image)([][]int){
	var matrix [][]int

	bounds := img.Bounds()

	for y := bounds.Min.Y; y < bounds.Max.Y; y++{
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			colorAt := img.At(x, y)
			c, _ := colorful.MakeColor(colorAt)

			val := 0.299 * c.R + 0.587 * c.G + 0.114 * c.B
			val = math.Round(val)
			matrix[x][y] = int(val)
		}
	}
	return matrix
}

func createCoOccurence(matrix [][]int)(*mat.Dense){
	occurence0 := mat.NewDense(256, 256, nil)

	// 0 angle
	row := len(matrix)
	col := len(matrix[0])

	for y := 0; y < col; y++{
		for x := 0; x < row; x++ {
			i := matrix[x][y]
			j := matrix[x][y+1]
			occurence0.Set(i, j, occurence0.At(i, j) + 1)
		}
	}

	transpose0 := mat.DenseCopyOf(occurence0.T())

	var sum0 mat.Dense
	sum0.Add(occurence0, transpose0)


	data0 := sum0.RawMatrix().Data 
	norm_val := floats.Sum(data0)
	

	normalizedMatrix0 := mat.NewDense(row, col, nil)
	normalizedMatrix0.Scale(1/norm_val, sum0)

	return normalizedMatrix0
}

func processPicture(filename string){
	// read file

	file, err := os.Open(filename)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	img, _, err := image.Decode(file)
    if err != nil {
        log.Fatal(err)
    }

	black := toBlack(img)

	occ_matrix := createCoOccurence(black)

	vecktor := featureExtraction(occ_matrix)
    
	// fmt.Println(img)
}

func main(){
	start := time.Now()

	vektor1 := processPicture("../images/marvel_kucing1.jpg")

	vektor2 := processPicture("../images/marvel_kucing3.jpg")

	var simmilarity float64
	simmilarity = cosine_similarity(vektor1, vektor2)

	elapsed := time.Since(start)
	fmt.Println("Execution time :", elapsed)

	fmt.Println("Simmilarity :", simmilarity )
}